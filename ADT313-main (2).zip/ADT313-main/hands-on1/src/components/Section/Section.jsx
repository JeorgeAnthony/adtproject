import './Section.css';

function Section() {
  return (
   <h2>Section</h2>
  );
}

export default Section;
